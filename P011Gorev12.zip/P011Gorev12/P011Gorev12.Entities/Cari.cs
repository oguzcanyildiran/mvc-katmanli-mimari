﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace P011Gorev12.Entities
{
    public class Cari : BaseObject
    {
        public int FirmaId { get; set; }
        [Display(Name = "Cari Ünvan"), StringLength(150)]
        public string CariUnvan { get; set; }
        public int CariTipId { get; set; }
        public int DövizCinsId { get; set; }
        public int AnaCariId { get; set; }
        public int CariPersonelId { get; set; }
        [Display(Name = "Muhasebe Kodu"), StringLength(50)]
        public string? MuhasebeKodu { get; set; }
        public int CariGrupId { get; set; }
        public int CariSektörId { get; set; }
        public int CariBögeId { get; set; }
        public int VergiDairesiId { get; set; }
        [Display(Name = "Vergi Numarası"), StringLength(50)]
        public string? VergiNo { get; set; }
        public int FaturaAdresiId { get; set; }
        [StringLength(50)]
        public string? Email { get; set; }
        [StringLength(50)]
        public string? WebUrl { get; set; }
        [StringLength(50)]
        public string? Telefon { get; set; }
        public int İskontoId { get; set; }
        public int FiyatListesiId { get; set; }
        [StringLength(50)]
        public string? YetkiliKisi { get; set; }
        [StringLength(50)]
        public string? YetkiliTelefon { get; set; }
        [StringLength(50)]
        public string? Aciklama { get; set; }
    }
}
