﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P011Gorev12.Entities
{
    public class Sehir : BaseObject
    {

        public int UlkeId { get; set; }
        [StringLength(50)]
        public string Kod { get; set; }
        [StringLength(150)]
        public string? Tanim { get; set; }
        [StringLength(500)]
        public string? Aciklama { get; set; }


    }
}
