﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P011Gorev12.DataAccess.Context
{
    internal class DataContext
    {
        public DbSet<Ilce> Ilce { get; set; }
        public DbSet<Sehir> Sehir { get; set; }
        public DbSet<Ulke> Ulke { get; set; }
       
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            optionsBuilder.UseSqlServer(@"Server=(localdb)\MSSQLLocalDB; Database=P011Gorev12; Trusted_Connection = True; ");
            base.OnConfiguring(optionsBuilder);
        }


    }
}
