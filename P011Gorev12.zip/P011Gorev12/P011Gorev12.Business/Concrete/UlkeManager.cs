﻿using P011Gorev12.Business.Abstract;
using P011Gorev12.DataAccess.Abstract;
using P011Gorev12.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P011Gorev12.Business.Concrete
{
    public class UlkeManager : IUlkeService
    {
        private readonly IUlkeRepository _ulkeRepository;

        public UlkeManager(IUlkeRepository ulkeRepository)
        {
            _ulkeRepository = ulkeRepository;
        }
        
        
        
        public Ulke create(Ulke entity)
        {
            return _ulkeRepository.create(entity);
        }

        public void Delete(int id)
        {
            _ulkeRepository.Delete(id);
        }

        public List<Ulke> GetAll()
        {
            return _ulkeRepository.GetAll();
        }
        public Ulke GetById(int id)
        {
            return _ulkeRepository.GetById(id);
        }

        public List<Ulke> GetlistByCity(string cityName)
        {
            throw new NotImplementedException();
        }

        public Ulke Update(Ulke entity)
        {
            return _ulkeRepository.Update(entity);
        }
    }
}
