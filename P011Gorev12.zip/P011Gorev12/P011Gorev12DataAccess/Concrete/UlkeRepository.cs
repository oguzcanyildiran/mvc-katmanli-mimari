﻿using P011Gorev12.DataAccess.Abstract;
using P011Gorev12.Entities;
using P011Gorev12.DataAccess.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P011Gorev12.DataAccess.Concrete
{
    internal class UlkeRepository : IUlkeRepository
    {
        public Ulke create(Ulke entity)
        {
            using (var _context = new DataContext())
            {
                _context.Ulke.Add(entity);
                _context.SaveChanges();
                return entity;
            }
        }
        public void Delete(int id)
        {
            using (var _context = new DataContext())
            {
                var silinecek = GetById(id);

                _context.Ulke.Remove(silinecek);
                _context.SaveChanges();

            }
        }

        public List<Ulke> GetAll()
        {
            using (var _context = new DataContext())
            {
                return _context.Ulke.ToList();
            }

        }
        public Ulke GetById(int id)
        { 
        using (var _context = new DataContext())
        {
            return _context.Ulke.Find(id);
        }
}
        public List<Ulke> GetlistByCity(string cityName)
        {
            throw new NotImplementedException();
        }

        public Ulke Update (Ulke entity)
        { 
        using (var _context = new DataContext())
        {
            _context.Ulke.Update(entity);
             _context.SaveChanges();
                return entity;
        }
        }
    }
}
