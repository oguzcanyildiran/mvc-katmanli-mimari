﻿using P011Gorev12.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P011Gorev12.DataAccess.Abstract
{
   public interface IUlkeRepository
    {
        List<Ulke> GetAll();
        Ulke GetById(int Id);
        List<Ulke> GetlistByCity(string cityName);
        Ulke create(Ulke entity);
        Ulke Update(Ulke entity);
        void Delete(int id);


    }
}
